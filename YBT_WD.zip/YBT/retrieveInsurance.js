

/**
 * @api {get} /ybt/api/v1/insurances?filterCriteria={filterCriteria} Retrieve Insurance Policy
 * @apiDescription Retrieve Insurance Policy
 * @apiVersion 0.0.1
 * @apiName Retrieve Insurance Policy
 * @apiGroup YBT
 * @apiExample Sample FilterCriteria 
{
	"customerNumber": "CNHSBC001123456"
}
 *
* @apiHeader {String} X-HSBC-Src-Device-Id ID of the device from where the request originated. Default implementation would be the IP address of the HTTP request.
* @apiHeader {String} X-HSBC-Src-UserAgent User agent from user's machine/browser.
* @apiHeader {String} X-HSBC-IP-Address IP Address of the request.
* @apiHeader {String="OHI","OHB"} X-HSBC-Channel-Id Identifier of the channel where the user.
* @apiHeader {String} X-HSBC-LOB HSBC line of business.
* @apiHeader {String} X-HSBC-Chnl-CountryCode The country code of consumer. Please don't use X-HSBC-Chnl-Country-Code.
* @apiHeader {String} X-HSBC-Chnl-Group-Member Group member of the current request user profile.
* @apiHeader {String} X-HSBC-Roles Semi-colon separate list of user roles. Staff channel.
* @apiHeader {String} X-HSBC-Locale ISO language code + ISO country code. 
*   <br/> <a>http://www.loc.gov/standards/iso639-2/englangn.html</a>
*   <br/> <a>http://www.iso.ch/iso/en/prods-services/iso3166ma/02iso-3166-code-lists/list-en1.html</a>
* @apiHeader {String} X-HSBC-Consumer-Id Consumer IDs (stored in R2DS).
* @apiHeader {String} X-HSBC-Session-Correlation-Id A unique session ID used to tie all the transactions done within a customer session. This ID is not the JSession ID.
* @apiHeader {String} X-HSBC-Request-Correlation-Id Global log ID, for end to end trace of a user request.
* @apiHeader {String} X-HSBC-Saml SAML token for authentication.
* @apiHeader {String} X-HSBC-Workstation-Id Workstation ID.
* @apiHeader {String} X-HSBC-User-Id Obtained from user principal, in the staff channel it would be the user's people soft IDs.
* @apiHeader {String} X-HSBC-CAM-Level HSBC customer authentication module level.
* @apiHeader {String} X-HSBC-IP-Country-Code The country code of the involved party. 
* @apiHeader {String} X-HSBC-IP-Group-Member Group member of the involved party. 
* @apiHeader {String} X-HSBC-IP-Id IP id is the id that the current user used to authenticate with the channel from which the user invokes the operation. <br/> E.g. internet channel is BE user ID, and peoplesoft ID of the staff user.
* @apiHeader {String="PFS","CMB"} X-HSBC-IP-Type The involved party type.
* @apiHeader {String} X-HSBC-IP-Segment The involved party segment. <br/> E.g. in PFS: retail, advance, premier
* @apiHeader {String} X-HSBC-IP-Delegate-Id ID of the person operating on behalf of the IP. <br/>
*   <li>PFS functions customer ID</li>
*   <li>CMB functions delegate ID</li>
* @apiHeader {String} X-HSBC-Login-Id CAM 10 ID.
* @apiHeader {String} X-HSBC-App-Id Application identification number.
* @apiHeader {String} X-HSBC-Company-Id Company identification number.
* @apiHeader {String} X-HSBC-Timestamp Indicates the message creation timestamp in milliseconds. <br/> E.g. capture date and capture time of the message.
* @apiHeader {String} X-HSBC-Timezone Abbreviated time zone. <br/> <a>https://www.timeanddate.com/time/zones/</a>
* @apiHeader {String} X-HSBC-Gu-Id Global SaaS login id.
 *
 * @apiParam {JSON} filterCriteria The JSON object for the filter criteria with URL encoded.
 * @apiParam {String} filterCriteria.customerNumber Denotes customer number. （客户号码）
 * 
* @apiSuccess {String[]} reasonCode Error reason code. （错误代码） 
* @apiSuccess {String} trackingNumber Tracking number of the error. （跟踪编码）
 * 
 * @apiSuccess {Object[]} insurancePolicies Denotes insurance policies.  （保单信息） 
 * 
 * @apiSuccess {Object} insurancePolicies.account Denotes account. （客户信息） 
 * @apiSuccess {String{1..30}} insurancePolicies.account.accountNumber Denotes account number. （客户保单号码）
 * @apiSuccess {String{1..3}} insurancePolicies.account.accountTypeCode Denotes account type code. Default as "INS". （客户类型）
 * @apiSuccess {String{3}} insurancePolicies.account.accountCurrencyCode Denotes account currency code. （客户币种）
 * 
 * @apiSuccess {String{1..30}} insurancePolicies.productCode Denotes product code. （产品代码）
 * @apiSuccess {String{1..30}} insurancePolicies.productInsurancetypeCode Denotes product insurance type code. （保单类型） 
 * @apiSuccess {String{3}} insurancePolicies.currencyCode Denotes currency code. （保单币种）
 * @apiSuccess {String{2}="IF","CF","CL","SU","MA","PO","TE","DH"} insurancePolicies.accountStatusCode Denotes the insurance policy status code. （保单状态）
 *    <li>IF - Effective 有效</li>
 *    <li>CF - Cancelled from Inception 犹豫期退保</li>
 *    <li>CL - Lapse 保单失效/Rescind(Cancel from Inception) 保单撤销（不实告知）</li>
 *    <li>SU - Surrender 保单退保</li>
 *    <li>MA - Contract Matured 保单满期/Expiry 保单终止</li>
 *    <li>PO - Contract Postponed 保单延期</li>
 *    <li>TE - Contract Terminated 保单终止</li>
 *    <li>DH - Approved Death Claim 死亡理赔</li>
 * @apiSuccess {Object[]} [insurancePolicies.funds] Denotes investment linked funds. （投资账户信息） 
 * @apiSuccess {String{1..30}} insurancePolicies.funds.fundCode Denotes fund code. （投资账户代码）
 * @apiSuccess {Number} insurancePolicies.funds.fundBalanceAmount Denotes fund balance amount. （投资账户价值）
 * @apiSuccess {Number} insurancePolicies.funds.fundUnitNumber Denotes fund unit number. （投资账户份额）
 * @apiSuccess {Number} insurancePolicies.funds.fundUnitPriceAmount Denotes fund unit price amount.（投资账户单价）
 * @apiSuccess {String{1..100}} insurancePolicies.funds.fundEnglishName Denotes fund English name. （投资账户英文名称）
 * @apiSuccess {String{1..100}} insurancePolicies.funds.fundChineseName Denotes fund Chinese name. （投资账户中文名称）
 * 
 * @apiSuccess {Object} insurancePolicies.insuranceCoverageArrangement Denotes insurance coverage arrangement. （保险范围信息）
 * @apiSuccess {Number} insurancePolicies.insuranceCoverageArrangement.coverageAmount Denotes coverage amount. （保额）
 * @apiSuccess {String{3}} insurancePolicies.insuranceCoverageArrangement.coverageAmountCcyCode Denotes coverage amount currency. （保额币种）
 * @apiSuccess {String{1..3}} [insurancePolicies.insuranceCoverageArrangement.paymentBenefitOptionCode] Denotes payment benefit option code. Default blank. （利益支出方式）
 * @apiSuccess {Number} [insurancePolicies.insuranceCoverageArrangement.paymentBenefitRegularAmount] Denotes payment benefit regular amount. Default blank. （每期利益支出金额）
 * @apiSuccess {String{3}} [insurancePolicies.insuranceCoverageArrangement.paymentBenefitRegularAmountCcyCode] Denotes payment benefit regular amount currency. Default blank. （每期利益支出金额币种）
 
 * @apiSuccess {Object} insurancePolicies.insurancePolicyArrangement Denotes insurance policy arrangement. 
 * @apiSuccess {Number} insurancePolicies.insurancePolicyArrangement.accountValueAmount Denotes account value amount. （保单现金价值）
 * @apiSuccess {String{3}} insurancePolicies.insurancePolicyArrangement.accountValueAmountCcyCode Denotes account currency code. （保单现金价值币种）
 * @apiSuccess {Number} insurancePolicies.insurancePolicyArrangement.paymentDividendIncomeToDateAmount Denotes payment dividend income to date. （红利金额） 
 * @apiSuccess {String{3}} insurancePolicies.insurancePolicyArrangement.paymentDividendIncomeToDateAmountCcyCode Denotes payment dividend income to date currency. （红利金额币种） 
 * @apiSuccess {String{4}="CA","CP","PR","SA","RB"} insurancePolicies.insurancePolicyArrangement.paymentDividendOptionCode Denotes payment dividend option code. （红利领取方式）
 *    <li>CA - Dividend accumulation 累积生息</li>
 *    <li>CR - Cash dividend 现金领取</li>
 *    <li>PR - Off-set against premium 抵交保费</li>
 *    <li>SA - Paid up addition 增额交清</li>
 *    <li>RB - Revisionary Bonus 增额红利</li>
 * @apiSuccess {String{0..30}} [insurancePolicies.insurancePolicyArrangement.paymentMethod] Denotes payment method. Default blank. （支付方法） 
 * @apiSuccess {String{1}="S","A","M","Q","H"} insurancePolicies.insurancePolicyArrangement.paymentPeriodicityCode Denotes payment periodicity code. （交费方式）
 *    <li>S - Single Pay 趸交</li>
 *    <li>A - Annually 年交</li>
 *    <li>M - Monthly  月交</li>
 *    <li>Q - Quarterly 季交</li>
 *    <li>H - Semi-Annual 半年交</li>
 * @apiSuccess {String[]{1..2}="A","M","Y","AC","AT"} [insurancePolicies.insurancePolicyArrangement.annuityOptions] Denotes the list of annuity options. （年金领取方式）
 *    <li>A - Annually 年领</li>
 *    <li>M - Monthly 月领</li>
 *    <li>Y - By Age 岁领</li>
 *    <li>AC - Accumulation 累积生息（申请领取）</li>
 *    <li>AT - Automatic transfer 自动转账</li>
 * @apiSuccess {Number} [insurancePolicies.insurancePolicyArrangement.annuityIncomeAmount] Denotes annuity income amount. （年金领取金额）
 * @apiSuccess {String{3}} [insurancePolicies.insurancePolicyArrangement.annuityIncomeAmountCcyCode] Denotes annuity income amount currency code. （年金领取金额币种）
 * @apiSuccess {Date} insurancePolicies.insurancePolicyArrangement.policyExpiryDate Denotes policy expiry date. Format: yyyy-MM-dd. （保单满期日） 
 * @apiSuccess {Date} insurancePolicies.insurancePolicyArrangement.policyStartDate Denotes policy start data. Format: yyyy-MM-dd. （保单生效日）
 * @apiSuccess {Date} insurancePolicies.insurancePolicyArrangement.policyValuationDate Denotes policy valuation date. Format: yyyy-MM-dd. （保险信息更新日）
 * @apiSuccess {Number} insurancePolicies.insurancePolicyArrangement.premiumRegularPaymentAmount Denotes premium regular payment amount. （期交保费）
 * @apiSuccess {String{3}} insurancePolicies.insurancePolicyArrangement.premiumRegularPaymentAmountCcyCode Denotes premium regular payment amount currency code. （期交保费币种）
 * @apiSuccess {Number} insurancePolicies.insurancePolicyArrangement.premiumTotalPaidAmount Denotes premium total paid amount. （已交保费） 
 * @apiSuccess {String{3}} insurancePolicies.insurancePolicyArrangement.premiumTotalPaidAmountCcyCode Denotes premium total paid amount currency code. （已交保费币种） 
 * @apiSuccess {Number} [insurancePolicies.insurancePolicyArrangement.valueGuaranteeMaturityAmount] Denotes value guarantee maturity amount. Default blank. （担保到期金额）
 * @apiSuccess {String{3}} [insurancePolicies.insurancePolicyArrangement.valueGuaranteeMaturityAmountCcyCode] Denotes value guarantee maturity amount currency code. Default blank. （担保到期金额币种）
 * @apiSuccess {Number} [insurancePolicies.insurancePolicyArrangement.valueGuaranteeToDateAmount] Denotes value guarantee to date amount. Default blank. （至今担保金额） 
 * @apiSuccess {String{3}} [insurancePolicies.insurancePolicyArrangement.valueGuaranteeToDateAmountCcyCode] Denotes value guarantee to date amount currency code. Default blank.  （至今担保金额币种） 
 * @apiSuccess {String{0..30}} [insurancePolicies.insurancePolicyArrangement.mandateType] Denotes policy mandate type. Default blank. （委托类型）
 * @apiSuccess {String{3}} insurancePolicies.insurancePolicyArrangement.paymentTerm Denotes the payment terms, with leading 0 padding. （交费年期） 
 * @apiSuccess {String{3}} insurancePolicies.insurancePolicyArrangement.paymentTermRemaining Denotes the remaining payment terms, with leading 0 padding. （剩余缴费期数）
 * @apiSuccess {String} insurancePolicies.insurancePolicyArrangement.nextPaymentDate Denotes the next payment date. Format: yyyy-MM-dd. （下一保费扣款日）
 * 
 * @apiSuccess {String[]{0..90}} insurancePolicies.insuredNames Denotes the list of insured names. （被保险人姓名）
 * @apiSuccess {String[]{0..90}} insurancePolicies.beneficiaryNames Denotes the list of beneficiary names. （受益人姓名）
 *  
 *  
 *  
 
 * @apiSuccessExample Success-Response:
 *HTTP/1.1 200 OK
{
	"reasonCodes": [],
	"insurancePolicies": [{
		"account": {
			"accountNumber": "000000540980",
			"accountTypeCode": "INS",
			"accountCurrencyCode": "CNY"
		},
		"productCode": "2EI",
		"accountStatusCode": "IF",
		"currencyCode": "SGD",
		"funds": [{
			"fundCode": "AUS1",
			"fundBalanceAmount": 60.64,
			"fundUnitNumber": 57.99958,
			"fundUnitPriceAmount": 1.04554,
			"fundEnglishName": "Green economy selected fund",
			"fundChineseName": "低碳环保精选投资账户"
		}],
		"insuranceCoverageArrangement": {
			"coverageAmount": 150000.00,
			"coverageAmountCcyCode": "CNY",
			"paymentBenefitOptionCode": "NA",
			"paymentBenefitRegularAmount": 0.00,
			"paymentBenefitRegularAmountCcyCode": "CNY"
		}, 
		"insurancePolicyArrangement": {
			"accountValueAmount": 203.15,
			"accountValueAmountCcyCode": "CNY",
			"paymentDividendIncomeToDateAmount": 0.00,
			"paymentDividendIncomeToDateAmountCcyCode": "CNY",
			"paymentDividendOptionCode": "CA",
			"paymentMethod": "Inter-bank GIRO",
			"paymentPeriodicityCode": "S",
			"annuityOptions": ["A", "AC", "AT"],
			"annuityIncomeAmount": 4200,
			"annuityIncomeAmountCcyCode": "CNY",
			"policyExpiryDate": "2110-11-22",
			"policyStartDate": "2012-11-22",
			"policyValuationDate": "2015-07-01",
			"premiumRegularPaymentAmount": 150.00,
			"premiumRegularPaymentAmountCcyCode": "CNY",
			"premiumTotalPaidAmount": 4800.00,
			"premiumTotalPaidAmountCcyCode": "CNY",
			"valueGuaranteeMaturityAmount": 0.00,
			"valueGuaranteeMaturityAmountCcyCode": "CNY",
			"valueGuaranteeToDateAmount": 203.15,
			"valueGuaranteeToDateAmountCcyCode": "CNY",
			"mandateType": null,
			"paymentTerm": "003",
			"paymentTermRemaining": "029",
			"nextPaymentDate": "2018-10-22"
		},
		"insuredNames": ["张三", "李四"],
		"beneficiaryNames": ["张三", "李四"]
	}]
}
* 
 * @apiErrorExample Bad Request
 *HTTP/1.1 400 Bad Request
* {
* }
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
 */