define({
  "name": "YBT Insurance Policy",
  "version": "0.0.1",
  "description": "YBT Insurance Policy",
  "title": "YBT Insurance Policy",
  "url": "",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-09-03T07:28:27.192Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
