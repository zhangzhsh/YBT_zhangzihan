define({ "api": [
  {
    "type": "get",
    "url": "/ybt/api/v1/insurances?filterCriteria={filterCriteria}",
    "title": "Retrieve Insurance Policy",
    "description": "<p>Retrieve Insurance Policy</p>",
    "version": "0.0.1",
    "name": "Retrieve_Insurance_Policy",
    "group": "YBT",
    "examples": [
      {
        "title": "Sample FilterCriteria ",
        "content": "{\n\t\"customerNumber\": \"CNHSBC001123456\"\n}",
        "type": "json"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Src-Device-Id",
            "description": "<p>ID of the device from where the request originated. Default implementation would be the IP address of the HTTP request.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Src-UserAgent",
            "description": "<p>User agent from user's machine/browser.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-IP-Address",
            "description": "<p>IP Address of the request.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "allowedValues": [
              "\"OHI\"",
              "\"OHB\""
            ],
            "optional": false,
            "field": "X-HSBC-Channel-Id",
            "description": "<p>Identifier of the channel where the user.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-LOB",
            "description": "<p>HSBC line of business.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Chnl-CountryCode",
            "description": "<p>The country code of consumer. Please don't use X-HSBC-Chnl-Country-Code.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Chnl-Group-Member",
            "description": "<p>Group member of the current request user profile.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Roles",
            "description": "<p>Semi-colon separate list of user roles. Staff channel.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Locale",
            "description": "<p>ISO language code + ISO country code. <br/> <a>http://www.loc.gov/standards/iso639-2/englangn.html</a> <br/> <a>http://www.iso.ch/iso/en/prods-services/iso3166ma/02iso-3166-code-lists/list-en1.html</a></p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Consumer-Id",
            "description": "<p>Consumer IDs (stored in R2DS).</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Session-Correlation-Id",
            "description": "<p>A unique session ID used to tie all the transactions done within a customer session. This ID is not the JSession ID.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Request-Correlation-Id",
            "description": "<p>Global log ID, for end to end trace of a user request.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Saml",
            "description": "<p>SAML token for authentication.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Workstation-Id",
            "description": "<p>Workstation ID.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-User-Id",
            "description": "<p>Obtained from user principal, in the staff channel it would be the user's people soft IDs.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-CAM-Level",
            "description": "<p>HSBC customer authentication module level.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-IP-Country-Code",
            "description": "<p>The country code of the involved party.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-IP-Group-Member",
            "description": "<p>Group member of the involved party.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-IP-Id",
            "description": "<p>IP id is the id that the current user used to authenticate with the channel from which the user invokes the operation. <br/> E.g. internet channel is BE user ID, and peoplesoft ID of the staff user.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "allowedValues": [
              "\"PFS\"",
              "\"CMB\""
            ],
            "optional": false,
            "field": "X-HSBC-IP-Type",
            "description": "<p>The involved party type.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-IP-Segment",
            "description": "<p>The involved party segment. <br/> E.g. in PFS: retail, advance, premier</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-IP-Delegate-Id",
            "description": "<p>ID of the person operating on behalf of the IP. <br/></p>   <li>PFS functions customer ID</li>   <li>CMB functions delegate ID</li>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Login-Id",
            "description": "<p>CAM 10 ID.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-App-Id",
            "description": "<p>Application identification number.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Company-Id",
            "description": "<p>Company identification number.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Timestamp",
            "description": "<p>Indicates the message creation timestamp in milliseconds. <br/> E.g. capture date and capture time of the message.</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Timezone",
            "description": "<p>Abbreviated time zone. <br/> <a>https://www.timeanddate.com/time/zones/</a></p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "X-HSBC-Gu-Id",
            "description": "<p>Global SaaS login id.</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "JSON",
            "optional": false,
            "field": "filterCriteria",
            "description": "<p>The JSON object for the filter criteria with URL encoded.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "filterCriteria.customerNumber",
            "description": "<p>Denotes customer number. （客户号码）</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "reasonCode",
            "description": "<p>Error reason code. （错误代码）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "trackingNumber",
            "description": "<p>Tracking number of the error. （跟踪编码）</p>"
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "insurancePolicies",
            "description": "<p>Denotes insurance policies.  （保单信息）</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "insurancePolicies.account",
            "description": "<p>Denotes account. （客户信息）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "1..30",
            "optional": false,
            "field": "insurancePolicies.account.accountNumber",
            "description": "<p>Denotes account number. （客户保单号码）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "1..3",
            "optional": false,
            "field": "insurancePolicies.account.accountTypeCode",
            "description": "<p>Denotes account type code. Default as &quot;INS&quot;. （客户类型）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "3",
            "optional": false,
            "field": "insurancePolicies.account.accountCurrencyCode",
            "description": "<p>Denotes account currency code. （客户币种）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "1..30",
            "optional": false,
            "field": "insurancePolicies.productCode",
            "description": "<p>Denotes product code. （产品代码）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "1..30",
            "optional": false,
            "field": "insurancePolicies.productInsurancetypeCode",
            "description": "<p>Denotes product insurance type code. （保单类型）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "3",
            "optional": false,
            "field": "insurancePolicies.currencyCode",
            "description": "<p>Denotes currency code. （保单币种）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "2",
            "allowedValues": [
              "\"IF\"",
              "\"CF\"",
              "\"CL\"",
              "\"SU\"",
              "\"MA\"",
              "\"PO\"",
              "\"TE\"",
              "\"DH\""
            ],
            "optional": false,
            "field": "insurancePolicies.accountStatusCode",
            "description": "<p>Denotes the insurance policy status code. （保单状态）</p>    <li>IF - Effective 有效</li>    <li>CF - Cancelled from Inception 犹豫期退保</li>    <li>CL - Lapse 保单失效/Rescind(Cancel from Inception) 保单撤销（不实告知）</li>    <li>SU - Surrender 保单退保</li>    <li>MA - Contract Matured 保单满期/Expiry 保单终止</li>    <li>PO - Contract Postponed 保单延期</li>    <li>TE - Contract Terminated 保单终止</li>    <li>DH - Approved Death Claim 死亡理赔</li>"
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": true,
            "field": "insurancePolicies.funds",
            "description": "<p>Denotes investment linked funds. （投资账户信息）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "1..30",
            "optional": false,
            "field": "insurancePolicies.funds.fundCode",
            "description": "<p>Denotes fund code. （投资账户代码）</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "insurancePolicies.funds.fundBalanceAmount",
            "description": "<p>Denotes fund balance amount. （投资账户价值）</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "insurancePolicies.funds.fundUnitNumber",
            "description": "<p>Denotes fund unit number. （投资账户份额）</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "insurancePolicies.funds.fundUnitPriceAmount",
            "description": "<p>Denotes fund unit price amount.（投资账户单价）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "1..100",
            "optional": false,
            "field": "insurancePolicies.funds.fundEnglishName",
            "description": "<p>Denotes fund English name. （投资账户英文名称）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "1..100",
            "optional": false,
            "field": "insurancePolicies.funds.fundChineseName",
            "description": "<p>Denotes fund Chinese name. （投资账户中文名称）</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "insurancePolicies.insuranceCoverageArrangement",
            "description": "<p>Denotes insurance coverage arrangement. （保险范围信息）</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "insurancePolicies.insuranceCoverageArrangement.coverageAmount",
            "description": "<p>Denotes coverage amount. （保额）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "3",
            "optional": false,
            "field": "insurancePolicies.insuranceCoverageArrangement.coverageAmountCcyCode",
            "description": "<p>Denotes coverage amount currency. （保额币种）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "1..3",
            "optional": true,
            "field": "insurancePolicies.insuranceCoverageArrangement.paymentBenefitOptionCode",
            "description": "<p>Denotes payment benefit option code. Default blank. （利益支出方式）</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": true,
            "field": "insurancePolicies.insuranceCoverageArrangement.paymentBenefitRegularAmount",
            "description": "<p>Denotes payment benefit regular amount. Default blank. （每期利益支出金额）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "3",
            "optional": true,
            "field": "insurancePolicies.insuranceCoverageArrangement.paymentBenefitRegularAmountCcyCode",
            "description": "<p>Denotes payment benefit regular amount currency. Default blank. （每期利益支出金额币种）</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement",
            "description": "<p>Denotes insurance policy arrangement.</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.accountValueAmount",
            "description": "<p>Denotes account value amount. （保单现金价值）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "3",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.accountValueAmountCcyCode",
            "description": "<p>Denotes account currency code. （保单现金价值币种）</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.paymentDividendIncomeToDateAmount",
            "description": "<p>Denotes payment dividend income to date. （红利金额）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "3",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.paymentDividendIncomeToDateAmountCcyCode",
            "description": "<p>Denotes payment dividend income to date currency. （红利金额币种）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "4",
            "allowedValues": [
              "\"CA\"",
              "\"CP\"",
              "\"PR\"",
              "\"SA\"",
              "\"RB\""
            ],
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.paymentDividendOptionCode",
            "description": "<p>Denotes payment dividend option code. （红利领取方式）</p>    <li>CA - Dividend accumulation 累积生息</li>    <li>CR - Cash dividend 现金领取</li>    <li>PR - Off-set against premium 抵交保费</li>    <li>SA - Paid up addition 增额交清</li>    <li>RB - Revisionary Bonus 增额红利</li>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "0..30",
            "optional": true,
            "field": "insurancePolicies.insurancePolicyArrangement.paymentMethod",
            "description": "<p>Denotes payment method. Default blank. （支付方法）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "1",
            "allowedValues": [
              "\"S\"",
              "\"A\"",
              "\"M\"",
              "\"Q\"",
              "\"H\""
            ],
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.paymentPeriodicityCode",
            "description": "<p>Denotes payment periodicity code. （交费方式）</p>    <li>S - Single Pay 趸交</li>    <li>A - Annually 年交</li>    <li>M - Monthly  月交</li>    <li>Q - Quarterly 季交</li>    <li>H - Semi-Annual 半年交</li>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "size": "1..2",
            "allowedValues": [
              "\"A\"",
              "\"M\"",
              "\"Y\"",
              "\"AC\"",
              "\"AT\""
            ],
            "optional": true,
            "field": "insurancePolicies.insurancePolicyArrangement.annuityOptions",
            "description": "<p>Denotes the list of annuity options. （年金领取方式）</p>    <li>A - Annually 年领</li>    <li>M - Monthly 月领</li>    <li>Y - By Age 岁领</li>    <li>AC - Accumulation 累积生息（申请领取）</li>    <li>AT - Automatic transfer 自动转账</li>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": true,
            "field": "insurancePolicies.insurancePolicyArrangement.annuityIncomeAmount",
            "description": "<p>Denotes annuity income amount. （年金领取金额）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "3",
            "optional": true,
            "field": "insurancePolicies.insurancePolicyArrangement.annuityIncomeAmountCcyCode",
            "description": "<p>Denotes annuity income amount currency code. （年金领取金额币种）</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.policyExpiryDate",
            "description": "<p>Denotes policy expiry date. Format: yyyy-MM-dd. （保单满期日）</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.policyStartDate",
            "description": "<p>Denotes policy start data. Format: yyyy-MM-dd. （保单生效日）</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.policyValuationDate",
            "description": "<p>Denotes policy valuation date. Format: yyyy-MM-dd. （保险信息更新日）</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.premiumRegularPaymentAmount",
            "description": "<p>Denotes premium regular payment amount. （期交保费）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "3",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.premiumRegularPaymentAmountCcyCode",
            "description": "<p>Denotes premium regular payment amount currency code. （期交保费币种）</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.premiumTotalPaidAmount",
            "description": "<p>Denotes premium total paid amount. （已交保费）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "3",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.premiumTotalPaidAmountCcyCode",
            "description": "<p>Denotes premium total paid amount currency code. （已交保费币种）</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": true,
            "field": "insurancePolicies.insurancePolicyArrangement.valueGuaranteeMaturityAmount",
            "description": "<p>Denotes value guarantee maturity amount. Default blank. （担保到期金额）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "3",
            "optional": true,
            "field": "insurancePolicies.insurancePolicyArrangement.valueGuaranteeMaturityAmountCcyCode",
            "description": "<p>Denotes value guarantee maturity amount currency code. Default blank. （担保到期金额币种）</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": true,
            "field": "insurancePolicies.insurancePolicyArrangement.valueGuaranteeToDateAmount",
            "description": "<p>Denotes value guarantee to date amount. Default blank. （至今担保金额）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "3",
            "optional": true,
            "field": "insurancePolicies.insurancePolicyArrangement.valueGuaranteeToDateAmountCcyCode",
            "description": "<p>Denotes value guarantee to date amount currency code. Default blank.  （至今担保金额币种）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "0..30",
            "optional": true,
            "field": "insurancePolicies.insurancePolicyArrangement.mandateType",
            "description": "<p>Denotes policy mandate type. Default blank. （委托类型）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "3",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.paymentTerm",
            "description": "<p>Denotes the payment terms, with leading 0 padding. （交费年期）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "size": "3",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.paymentTermRemaining",
            "description": "<p>Denotes the remaining payment terms, with leading 0 padding. （剩余缴费期数）</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "insurancePolicies.insurancePolicyArrangement.nextPaymentDate",
            "description": "<p>Denotes the next payment date. Format: yyyy-MM-dd. （下一保费扣款日）</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "size": "0..90",
            "optional": false,
            "field": "insurancePolicies.insuredNames",
            "description": "<p>Denotes the list of insured names. （被保险人姓名）</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "size": "0..90",
            "optional": false,
            "field": "insurancePolicies.beneficiaryNames",
            "description": "<p>Denotes the list of beneficiary names. （受益人姓名）</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n\t\"reasonCodes\": [],\n\t\"insurancePolicies\": [{\n\t\t\"account\": {\n\t\t\t\"accountNumber\": \"000000540980\",\n\t\t\t\"accountTypeCode\": \"INS\",\n\t\t\t\"accountCurrencyCode\": \"CNY\"\n\t\t},\n\t\t\"productCode\": \"2EI\",\n\t\t\"accountStatusCode\": \"IF\",\n\t\t\"currencyCode\": \"SGD\",\n\t\t\"funds\": [{\n\t\t\t\"fundCode\": \"AUS1\",\n\t\t\t\"fundBalanceAmount\": 60.64,\n\t\t\t\"fundUnitNumber\": 57.99958,\n\t\t\t\"fundUnitPriceAmount\": 1.04554,\n\t\t\t\"fundEnglishName\": \"Green economy selected fund\",\n\t\t\t\"fundChineseName\": \"低碳环保精选投资账户\"\n\t\t}],\n\t\t\"insuranceCoverageArrangement\": {\n\t\t\t\"coverageAmount\": 150000.00,\n\t\t\t\"coverageAmountCcyCode\": \"CNY\",\n\t\t\t\"paymentBenefitOptionCode\": \"NA\",\n\t\t\t\"paymentBenefitRegularAmount\": 0.00,\n\t\t\t\"paymentBenefitRegularAmountCcyCode\": \"CNY\"\n\t\t}, \n\t\t\"insurancePolicyArrangement\": {\n\t\t\t\"accountValueAmount\": 203.15,\n\t\t\t\"accountValueAmountCcyCode\": \"CNY\",\n\t\t\t\"paymentDividendIncomeToDateAmount\": 0.00,\n\t\t\t\"paymentDividendIncomeToDateAmountCcyCode\": \"CNY\",\n\t\t\t\"paymentDividendOptionCode\": \"CA\",\n\t\t\t\"paymentMethod\": \"Inter-bank GIRO\",\n\t\t\t\"paymentPeriodicityCode\": \"S\",\n\t\t\t\"annuityOptions\": [\"A\", \"AC\", \"AT\"],\n\t\t\t\"annuityIncomeAmount\": 4200,\n\t\t\t\"annuityIncomeAmountCcyCode\": \"CNY\",\n\t\t\t\"policyExpiryDate\": \"2110-11-22\",\n\t\t\t\"policyStartDate\": \"2012-11-22\",\n\t\t\t\"policyValuationDate\": \"2015-07-01\",\n\t\t\t\"premiumRegularPaymentAmount\": 150.00,\n\t\t\t\"premiumRegularPaymentAmountCcyCode\": \"CNY\",\n\t\t\t\"premiumTotalPaidAmount\": 4800.00,\n\t\t\t\"premiumTotalPaidAmountCcyCode\": \"CNY\",\n\t\t\t\"valueGuaranteeMaturityAmount\": 0.00,\n\t\t\t\"valueGuaranteeMaturityAmountCcyCode\": \"CNY\",\n\t\t\t\"valueGuaranteeToDateAmount\": 203.15,\n\t\t\t\"valueGuaranteeToDateAmountCcyCode\": \"CNY\",\n\t\t\t\"mandateType\": null,\n\t\t\t\"paymentTerm\": \"003\",\n\t\t\t\"paymentTermRemaining\": \"029\",\n\t\t\t\"nextPaymentDate\": \"2018-10-22\"\n\t\t},\n\t\t\"insuredNames\": [\"张三\", \"李四\"],\n\t\t\"beneficiaryNames\": [\"张三\", \"李四\"]\n\t}]\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Bad Request",
          "content": "HTTP/1.1 400 Bad Request\n{\n}",
          "type": "json"
        }
      ]
    },
    "filename": "./retrieveInsurance.js",
    "groupTitle": "YBT"
  }
] });
